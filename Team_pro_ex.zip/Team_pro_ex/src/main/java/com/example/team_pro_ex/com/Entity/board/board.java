package com.example.team_pro_ex.com.Entity.board;

public class board {
       

}
